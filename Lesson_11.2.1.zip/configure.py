path_all_candidates_datas = "candidates.json"
